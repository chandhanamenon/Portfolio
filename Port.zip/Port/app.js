var bodyParser = require("body-parser"),
methodOverride = require("method-override"),	
expressSanitizer= require("express-sanitizer"),		
express        = require("express"),
app            = express();


app.set("view engine" , "ejs");
app.use(express.static("public"));
app.use(bodyParser.urlencoded({extended : true}));
app.use(expressSanitizer()); 
app.use(methodOverride("_method"))


app.get("/", function(req, res){
	
	res.render("index",{link:'https://github.com/chandhanamenon/Portfolio/blob/master/resume.pdf',spur:'https://github.com/chandhanamenon/Spur-Version1',ukiyo:'https://github.com/chandhanamenon/Ukiyo-Robstop',tutor:'https://github.com/chandhanamenon/Tutor-App/tree/master',linkedin:'https://www.linkedin.com/in/chandhana-menon-7054631a2',github:'https://github.com/chandhanamenon'})

})



app.listen(process.env.PORT, process.env.IP, function(){
	
	console.log("Portfolio is running");
	
});